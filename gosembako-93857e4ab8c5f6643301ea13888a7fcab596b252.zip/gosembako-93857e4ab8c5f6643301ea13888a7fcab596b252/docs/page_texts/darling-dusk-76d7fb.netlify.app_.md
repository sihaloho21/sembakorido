# GoSembako – Paket Sembako Murah

**URL:** https://darling-dusk-76d7fb.netlify.app/

---

GoSembako
Login Admin
Paket Sembako Murah & Lengkap

Kebutuhan pokok keluarga Anda, kami sediakan dengan harga terbaik.

Lihat Katalog
Katalog Produk
Paket Sembako 1
Stok Tersedia
Share

HARGA CASH

Rp 50.000

BAYAR GAJIAN

Rp 51.500

Tambah ke Keranjang
Rincian
Beli Sekarang

Diantar Nikomas - Diantar Kerumah - Ambil Ditempat

Paket Sembako 2
Stok Terbatas (5)
Share

HARGA CASH

Rp 200.000

BAYAR GAJIAN

Rp 206.000

Tambah ke Keranjang
Rincian
Beli Sekarang

Diantar Nikomas - Diantar Kerumah - Ambil Ditempat

Paket Sembako 3
Stok Terbatas (3)
Share

HARGA CASH

Rp 140.000

BAYAR GAJIAN

Rp 144.200

Tambah ke Keranjang
Rincian
Beli Sekarang

Diantar Nikomas - Diantar Kerumah - Ambil Ditempat

Paket Sembako 4
Stok Terbatas (1)
Share

HARGA CASH

Rp 150.000

BAYAR GAJIAN

Rp 154.500

Tambah ke Keranjang
Rincian
Beli Sekarang

Diantar Nikomas - Diantar Kerumah - Ambil Ditempat

Paket Sembako 5
Stok Habis
Share

HARGA CASH

Rp 135.000

BAYAR GAJIAN

Rp 139.050

Tambah ke Keranjang
Rincian
Beli Sekarang

Diantar Nikomas - Diantar Kerumah - Ambil Ditempat

© 2026 GoSembako Sembako. Semua Hak Dilindungi.